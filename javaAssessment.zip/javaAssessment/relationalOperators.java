public class relationalOperators{
	public static void main (String[] args){
		int x = 10;
		int y = 20;
		//false
		System.out.println(x == y);
		//true
		System.out.println(x != y);
		//false
		System.out.println(x > y);
		//true
		System.out.println(x < y);
		//false
		System.out.println(x >= y);
		//true
		System.out.println(x <= y);
	}

}