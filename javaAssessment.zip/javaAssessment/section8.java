//section8- Dealing with decimals Numbers
//float- this is a number that has a decimal. takes 7 digits after the decimal.
//double - this is a number that is bigger than int. takes 15 digits after decimals
public class section8{
	public static void main(String[] args){
	float age=25.5f;
	double age1= 14.5;
	System.out.println(age+age1);
	}
}

