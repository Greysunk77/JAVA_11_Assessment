//section 5 
public class section5_stringToNumeric{
	public static void main(String[] args){
	String name= "123456";
	int s = Integer.parseInt(name);
	System.out.println(s);
	}
}