public class bitwiseOperators{
	public static void main (String[] args){
		int a = 5; // 0101 in binary
		int b = 3; // 0011 in binary
		System.out.println(a & b);
		System.out.println(a | b);
		System.out.println(a ^ b);
		System.out.println(~a);
		System.out.println(a << 1);
		System.out.println(a >> 1);
	}

}