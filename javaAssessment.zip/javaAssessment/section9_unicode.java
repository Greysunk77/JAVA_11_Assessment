//section 9
//The unicode is the standard that provides a code for letters and symbols for all languages in the world.
//unicode is important in java because java is a high level langauge. 
public class section9_unicode{
	public static void main(String[] args){
	char ch='\u0045';
	//char ch=65;
	System.out.println(ch);
	}
}	