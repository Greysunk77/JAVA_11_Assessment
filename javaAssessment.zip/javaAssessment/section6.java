import java.util.Scanner;
public class section6{
	public static void main(String[] args){
		//user input for a
		System.out.println("Please insert value for A");
		Scanner scanner = new Scanner(System.in);
		int a =scanner.nextInt();
		// user input for b
		System.out.println("Please  insert value for B");
		
		int b =scanner.nextInt();
		int c = a+b;
		//OUTPUT
		System.out.println("The sum of A and B is : "+c);	
	}
}